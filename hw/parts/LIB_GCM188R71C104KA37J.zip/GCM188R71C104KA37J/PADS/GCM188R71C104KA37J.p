*PADS-LIBRARY-PART-TYPES-V9*

GCM188R71C104KA37J CAPC1608X90N I CAP 7 1 0 0 0
TIMESTAMP 2025.05.10.21.12.01
"Mouser Part Number" 81-GCM188R71C104KA7J
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Murata-Electronics/GCM188R71C104KA37J?qs=bGEzvQhTDnZD08oWyjLpYQ%3D%3D
"Manufacturer_Name" Murata Electronics
"Manufacturer_Part_Number" GCM188R71C104KA37J
"Description" Multilayer Ceramic Capacitors MLCC - SMD/SMT .1uF 16Volts 10%
"Datasheet Link" https://search.murata.co.jp/Ceramy/image/img/A01X/G101/ENG/GCM188R71C104KA37-01A.pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
GCM188R71C104KA37J
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
771762/1454039/2.50/2/2/Capacitor
