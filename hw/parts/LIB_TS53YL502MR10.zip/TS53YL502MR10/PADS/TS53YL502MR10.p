*PADS-LIBRARY-PART-TYPES-V9*

TS53YL502MR10 TS53YL502MR10 I RES 9 1 0 0 0
TIMESTAMP 2025.05.10.22.37.56
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" TS53YL502MR10
"Mouser Part Number" 72-TS53YL-5K
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Sfernice/TS53YL502MR10?qs=R4%2FAj8xQbdVgAZQT1Wga6w%3D%3D
"Arrow Part Number" TS53YL502MR10
"Arrow Price/Stock" https://www.arrow.com/en/products/ts53yl502mr10/vishay?region=nac
"Description" YL SMT 1-turn cermet trimmer,5K0 0.2W Vishay TS53YL Series SMD Cermet Trimmer Resistor with J-Hook Terminations, 5k +/-20% 0.25W +/-100ppm/C Top Adjust
"Datasheet Link" https://www.vishay.com/docs/51008/ts53.pdf
"Geometry.Height" 2.7mm
GATE 1 3 0
TS53YL502MR10
A1 0 U CCW
B1 0 U WIPER
C1 0 U CW

*END*
*REMARK* SamacSys ECAD Model
259020/1454039/2.50/3/4/Resistor
