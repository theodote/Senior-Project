*PADS-LIBRARY-PART-TYPES-V9*

SJ2-35894B-SMT-TR SJ235894BSMTTR I CON 7 1 0 0 0
TIMESTAMP 2025.05.09.22.39.42
"Mouser Part Number" 490-SJ2-35894BSMT-TR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Same-Sky/SJ2-35894B-SMT-TR?qs=DXv0QSHKF4zrn8ch4312EQ%3D%3D
"Manufacturer_Name" Same Sky
"Manufacturer_Part_Number" SJ2-35894B-SMT-TR
"Description" 4 conductor, 3.5 mm, SMT Audio Jack w/ Tip Switch
"Datasheet Link" https://www.sameskydevices.com/product/resource/sj2-3589x-smt.pdf
"Geometry.Height" 5.2mm
GATE 1 5 0
SJ2-35894B-SMT-TR
1 0 U SLEEVE
2 0 U TIP
3 0 U RING_1
4 0 U RING_2
10 0 U TIP_SWITCH

*END*
*REMARK* SamacSys ECAD Model
12178177/1454039/2.50/5/2/Connector
