*PADS-LIBRARY-PART-TYPES-V9*

OPA2323IDR SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.05.09.21.55.05
"Mouser Part Number" 595-OPA2323IDR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/OPA2323IDR?qs=Z%252BL2brAPG1LGR3B1pplHPw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" OPA2323IDR
"Description" Operational Amplifiers - Op Amps OP AMPS
"Datasheet Link" https://www.ti.com/lit/ds/symlink/opa2323.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
OPA2323IDR
1 0 U OUT1
2 0 U IN1-
3 0 U IN1+
4 0 U V-
8 0 U V+
7 0 U OUT2
6 0 U IN2-
5 0 U IN2+

*END*
*REMARK* SamacSys ECAD Model
19110005/1454039/2.50/8/3/Integrated Circuit
