*PADS-LIBRARY-PART-TYPES-V9*

61300811121 HDRV8W64P0X254_1X8_2032X254X854P I CON 7 1 0 0 0
TIMESTAMP 2025.05.11.17.08.36
"Mouser Part Number" 710-61300811121
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/61300811121?qs=PhR8RmCirEZRdx%252BVlEmRRA%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 61300811121
"Description" WR-PHD 2.54mm Pin Header THT Straight 8p Wurth Elektronik WR-PHD Series, Series Number 6130, 2.54mm Pitch 8 Way 1 Row Straight Pin Header, Surface Mount
"Datasheet Link" http://katalog.we-online.de/em/datasheet/6130xx11121.pdf
"Geometry.Height" 8.54mm
GATE 1 8 0
61300811121
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8

*END*
*REMARK* SamacSys ECAD Model
671258/1454039/2.50/8/3/Connector
