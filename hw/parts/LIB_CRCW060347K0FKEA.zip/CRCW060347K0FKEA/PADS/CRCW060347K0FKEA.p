*PADS-LIBRARY-PART-TYPES-V9*

CRCW060347K0FKEA RESC1608X50N I RES 7 1 0 0 0
TIMESTAMP 2025.05.09.22.20.36
"Mouser Part Number" 71-CRCW0603-47K-E3
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Vishay-Dale/CRCW060347K0FKEA?qs=yJVtgANCw03gcaACf6JZKA%3D%3D
"Manufacturer_Name" Vishay
"Manufacturer_Part_Number" CRCW060347K0FKEA
"Description" CRCW0603 Resistor T/R 0.10W,1%,47K Vishay CRCW Series Thick Film Surface Mount Resistor 0603 Case 47k +/-1% 0.1W +/-100ppm/C
"Datasheet Link" http://www.vishay.com/docs/20035/dcrcwe3.pdf
"Geometry.Height" 0.5mm
GATE 1 2 0
CRCW060347K0FKEA
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
185744/1454039/2.50/2/5/Resistor
