*PADS-LIBRARY-PART-TYPES-V9*

61301011121 HDRV10W64P0X254_1X10_2540X254X854P I CON 7 1 0 0 0
TIMESTAMP 2025.05.11.17.09.31
"Mouser Part Number" 710-61301011121
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/61301011121?qs=ZtY9WdtwX548wETl0P4xpA%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 61301011121
"Description" WR-PHD 2.54mm Pin Header 10pin Wurth Elektronik 613 Series, 2.54mm Pitch 10 Way 1 Row Straight PCB Header, Solder Pin Termination, 3A
"Datasheet Link" 
"Geometry.Height" 8.54mm
GATE 1 10 0
61301011121
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8
9 0 U 9
10 0 U 10

*END*
*REMARK* SamacSys ECAD Model
233557/1454039/2.50/10/3/Connector
