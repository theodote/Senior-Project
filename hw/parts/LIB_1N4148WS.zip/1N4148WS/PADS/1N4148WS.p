*PADS-LIBRARY-PART-TYPES-V9*

1N4148WS SODFL2512X90N I DIO 7 1 0 0 0
TIMESTAMP 2025.05.10.21.34.52
"Mouser Part Number" 512-1N4148WS
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/onsemi-Fairchild/1N4148WS?qs=2%2FYqgE%252BHg%252BKBrKZlAsMLhw%3D%3D
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" 1N4148WS
"Description" ON Semiconductor Switching Diode, 300mA 75V, 2-Pin SOD-323 1N4148WS
"Datasheet Link" https://www.onsemi.com/pub/Collateral/1N4148WS-D.PDF
"Geometry.Height" 0.9mm
GATE 1 2 0
1N4148WS
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
970186/1454039/2.50/2/2/Diode
