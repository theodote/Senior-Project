*PADS-LIBRARY-PART-TYPES-V9*

SMDTD04470YA00KS00 SMDTD04470YA00KS00 I CAP 7 1 0 0 0
TIMESTAMP 2025.05.10.20.30.40
"Mouser Part Number" 505-SMDTD04470YA00KS
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/WIMA/SMDTD04470YA00KS00?qs=DvsTirrhYfOFkMetk04INQ%3D%3D
"Manufacturer_Name" WIMA
"Manufacturer_Part_Number" SMDTD04470YA00KS00
"Description" Film Capacitors 4.7 uF 100 VDC 10%
"Datasheet Link" 
"Geometry.Height" 7.3mm
GATE 1 2 0
SMDTD04470YA00KS00
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
1258169/1454039/2.50/2/4/Capacitor
